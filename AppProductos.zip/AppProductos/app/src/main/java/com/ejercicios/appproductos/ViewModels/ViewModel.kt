package com.ejercicios.appproductos.ViewModels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.ejercicios.appproductos.Model.Producto
import com.ejercicios.appproductos.State.ProductoState
import java.time.LocalDate

class ViewModel : ViewModel() {

    var productos: MutableList<Producto> = mutableStateListOf() // Asegurarse de que sea MutableList
    var estado by mutableStateOf(ProductoState())
        private set

    init {
        viewModelScope.launch {
            // Espera 2 segundos.
            delay(2000)

            // Cargar los datos.
            estado = estado.copy(
                productos = listOf(
                    Producto("Coca-Cola 2L", "Coca-Cola 2L Original", 35.0, LocalDate.now()),
                    Producto("Paleta Payaso", "Chocolate y gomitas", 20.0, LocalDate.now()),
                    Producto("Doritos", "Bolsa de frituras", 20.0, LocalDate.now()),
                    Producto("Jugo de mango", "Jugo marca Jumex sabor mango", 25.00, LocalDate.now()),
                    Producto("Jugo de durazno", "Jugo marca Jumex sabor durazno", 25.00, LocalDate.now()),
                ),
                estaCargando = false
            )
        }
    }

    fun addProduct(nombre: String, precio: Double, descripcion: String, fecha: LocalDate) {
        val nuevoProducto = Producto(nombre, descripcion, precio, fecha) // Asegúrate de que Producto tenga un campo de precio como Double
        productos.add(nuevoProducto)
        estado = estado.copy(productos = productos.toList())
    }
}
