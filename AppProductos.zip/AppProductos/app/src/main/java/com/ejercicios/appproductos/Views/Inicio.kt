package com.ejercicios.appproductos.Views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ejercicios.appproductos.R

@Composable
fun InicioScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Espacio superior vacío
        Spacer(modifier = Modifier.height(20.dp))

        // Logo grande centrado
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                painter = painterResource(id= R.drawable.icon_logo), // Icono del logo de la empresa
                contentDescription = "Logo de la Empresa",
                modifier = Modifier
                    .size(120.dp) // Tamaño del logo
                    .padding(bottom = 16.dp)
            )
            Text(
                text = "NewGreenLand",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
        }

        // Botones apilados
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { navController.navigate("productos") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Productos")
            }

            Button(
                onClick = { navController.navigate("presentacion") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Presentación")
            }
        }

        // Nombre en la parte inferior
        Text(
            text = "Fernando Erubiel Torres Viniegra",
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}
